import { NextResponse } from 'next/server';

// Helper to get access token from Google OAuth2 using a Refresh Token
async function refreshGoogleAccessToken(clientId: string, clientSecret: string, refreshToken: string) {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token'
    })
  });
  
  if (!res.ok) {
    throw new Error(`Google OAuth error: ${res.status} ${await res.text()}`);
  }
  
  const data = await res.json();
  return data.access_token;
}

export async function GET() {
  try {
    let clientId = process.env.GOOGLE_CLIENT_ID;
    let clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    let refreshToken = process.env.GOOGLE_REFRESH_TOKEN;
    let folderId = process.env.GOOGLE_DRIVE_FOLDER_ID;

    if (clientId) clientId = clientId.trim().replace(/^['"]|['"]$/g, '');
    if (clientSecret) clientSecret = clientSecret.trim().replace(/^['"]|['"]$/g, '');
    if (refreshToken) refreshToken = refreshToken.trim().replace(/^['"]|['"]$/g, '');
    if (folderId) folderId = folderId.trim().replace(/^['"]|['"]$/g, '');

    if (!clientId || !clientSecret || !refreshToken) {
      return NextResponse.json({
        mocked: true,
        folderId: "mock-folder"
      });
    }

    try {
      const accessToken = await refreshGoogleAccessToken(clientId, clientSecret, refreshToken);
      return NextResponse.json({
        accessToken,
        folderId
      });
    } catch (refreshErr) {
      console.warn("Failed to refresh Google access token in GET, falling back to mock upload:", refreshErr);
      return NextResponse.json({
        mocked: true,
        folderId: "mock-folder"
      });
    }
  } catch (error: any) {
    console.error("Failed to get Google Access Token:", error);
    return NextResponse.json({ error: error?.message || 'Failed to get access token' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const employeeId = formData.get('employeeId') as string;
    const documentType = formData.get('documentType') as string; // offerLetter, panCard, aadhaarCard, bankDetails

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    let clientId = process.env.GOOGLE_CLIENT_ID;
    let clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    let refreshToken = process.env.GOOGLE_REFRESH_TOKEN;
    let folderId = process.env.GOOGLE_DRIVE_FOLDER_ID;

    // Automatically strip surrounding quotes if they were copied into settings
    if (clientId) clientId = clientId.trim().replace(/^['"]|['"]$/g, '');
    if (clientSecret) clientSecret = clientSecret.trim().replace(/^['"]|['"]$/g, '');
    if (refreshToken) refreshToken = refreshToken.trim().replace(/^['"]|['"]$/g, '');
    if (folderId) folderId = folderId.trim().replace(/^['"]|['"]$/g, '');

    // Fallback: If credentials are not set, return a mock successful upload
    if (!clientId || !clientSecret || !refreshToken) {
      console.warn("GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, or GOOGLE_REFRESH_TOKEN is missing. Using fallback mock upload.");
      
      // Simulate slow network upload
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockFileId = `sim-drive-${Date.now()}`;
      return NextResponse.json({
        success: true,
        fileId: mockFileId,
        fileName: file.name,
        webViewLink: `https://drive.google.com/file/d/${mockFileId}/view?usp=drivesdk`,
        mocked: true,
        message: 'Google credentials not configured. Using placeholder URL.'
      });
    }

    // Convert file to buffer
    const arrayBuffer = await file.arrayBuffer();
    const fileBuffer = Buffer.from(arrayBuffer);

    // Get access token
    let accessToken;
    try {
      accessToken = await refreshGoogleAccessToken(clientId, clientSecret, refreshToken);
    } catch (tokenErr) {
      console.warn("Failed to get Google Access Token (using simulated upload fallback):", tokenErr);
      const mockFileId = `sim-drive-${Date.now()}`;
      return NextResponse.json({
        success: true,
        fileId: mockFileId,
        fileName: file.name,
        webViewLink: `https://drive.google.com/file/d/${mockFileId}/view?usp=drivesdk`,
        mocked: true,
        message: 'Google authorization expired. Simulation URL returned for testing.'
      });
    }

    // Create Drive upload metadata
    const metadata: any = {
      name: file.name
    };
    if (folderId) {
      metadata.parents = [folderId];
    }

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartBody = Buffer.concat([
      Buffer.from(delimiter + 'Content-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify(metadata) + delimiter),
      Buffer.from(`Content-Type: ${file.type || 'application/octet-stream'}\r\n\r\n`),
      fileBuffer,
      Buffer.from(closeDelimiter)
    ]);

    const uploadRes = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id,name,webViewLink', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
        'Content-Length': multipartBody.length.toString()
      },
      body: multipartBody
    });

    if (!uploadRes.ok) {
      const errText = await uploadRes.text();
      console.warn("Google Drive API error (using simulated upload fallback):", errText);
      
      const mockFileId = `sim-drive-${Date.now()}`;
      return NextResponse.json({
        success: true,
        fileId: mockFileId,
        fileName: file.name,
        webViewLink: `https://drive.google.com/file/d/${mockFileId}/view?usp=drivesdk`,
        mocked: true,
        message: 'Google Drive quota limit hit. Simulation URL returned for testing.'
      });
    }

    const driveData = await uploadRes.json();

    // Set permission to anyone with the link can view (reader)
    try {
      await fetch(`https://www.googleapis.com/drive/v3/files/${driveData.id}/permissions?supportsAllDrives=true`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          role: 'reader',
          type: 'anyone'
        })
      });
    } catch (permErr) {
      console.warn("Failed to set open read permission for Drive file:", permErr);
    }

    return NextResponse.json({
      success: true,
      fileId: driveData.id,
      fileName: driveData.name,
      webViewLink: driveData.webViewLink
    });

  } catch (error: any) {
    console.error("Failed to upload document to Google Drive:", error);
    return NextResponse.json({ error: error?.message || 'Failed to upload document' }, { status: 500 });
  }
}
