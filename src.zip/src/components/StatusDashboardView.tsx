"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import { RefreshCw, Send, Clock, CheckCircle2, XCircle, AlertCircle, Calendar, FileText, Trash2, Sunrise, Sun, Sunset, BarChart2 } from "lucide-react";
import { createClient } from "@supabase/supabase-js";

interface StatusRequest {
  id: string;
  employee_id: string;
  employee_name: string;
  employee_phone: string;
  project: string;
  department: string;
  schedule_label: string;
  scheduled_time: string;
  sent_at: string;
  reply_deadline: string;
  reply_time: string | null;
  status: "pending" | "sent" | "replied" | "not_replied";
  update_text: string;
  report_id?: string;
  created_at: string;
}

interface StatusDashboardProps {
  onViewReport?: (reportId: string) => void;
  onShowToast?: (message: string, type: "success" | "error") => void;
}

const SCHEDULE_LABELS: Record<string, { label: string; icon: any }> = {
  morning: { label: "10:00 AM", icon: Sunrise },
  midday: { label: "1:00 PM", icon: Sun },
  evening: { label: "6:00 PM", icon: Sunset },
};

function formatTime(iso: string | null): string {
  if (!iso) return "--";
  return new Date(iso).toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

function getResponseTime(sentAt: string | null, replyTime: string | null): string {
  if (!sentAt || !replyTime) return "--";
  const diffMs = new Date(replyTime).getTime() - new Date(sentAt).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "<1 min";
  return `${mins} min`;
}

function isRequestExpired(replyDeadline: string, currentStatus: string): boolean {
  if (currentStatus !== "sent") return false;
  return new Date(replyDeadline).getTime() < Date.now();
}

export default function StatusDashboardView({ onViewReport, onShowToast }: StatusDashboardProps) {
  const [requests, setRequests] = useState<StatusRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [selectedDate, setSelectedDate] = useState(() => {
    const now = new Date();
    const istOffset = 5.5 * 60 * 60 * 1000;
    return new Date(now.getTime() + istOffset).toISOString().split("T")[0];
  });

  const fetchRequests = useCallback(async () => {
    try {
      const res = await fetch(`/api/status-requests?date=${selectedDate}`);
      const data = await res.json();
      if (data.requests) {
        setRequests(data.requests);
      }
    } catch (err) {
      console.error("Failed to fetch status requests:", err);
    } finally {
      setLoading(false);
    }
  }, [selectedDate]);

  // Initial fetch and polling
  useEffect(() => {
    const initializeDashboard = async () => {
      setLoading(true);
      // Run checker on load to instantly catch any expired requests
      await fetch("/api/status-requests/check-timeouts").catch(() => {});
      await fetchRequests();
    };
    initializeDashboard();

    // Poll for timeout checks every 30 seconds
    const interval = setInterval(async () => {
      await fetch("/api/status-requests/check-timeouts").catch(() => {});
      await fetchRequests();
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchRequests]);



  // Supabase Realtime subscription
  useEffect(() => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn("[StatusDashboard] Supabase public keys not set, skipping Realtime.");
      return;
    }

    const realtimeClient = createClient(supabaseUrl, supabaseAnonKey);

    const channel = realtimeClient
      .channel("status_requests_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "status_requests",
        },
        (payload) => {
          console.log("[StatusDashboard] Realtime update:", payload.eventType);

          if (payload.eventType === "INSERT") {
            const newRow = payload.new as StatusRequest;
            setRequests((prev) => [newRow, ...prev]);
          } else if (payload.eventType === "UPDATE") {
            const updated = payload.new as StatusRequest;
            setRequests((prev) =>
              prev.map((r) => (r.id === updated.id ? updated : r))
            );
          } else if (payload.eventType === "DELETE") {
            const deleted = payload.old as { id: string };
            setRequests((prev) => prev.filter((r) => r.id !== deleted.id));
          }
        }
      )
      .subscribe();

    return () => {
      realtimeClient.removeChannel(channel);
    };
  }, []);

  // Send status requests manually
  const sendNow = async (schedule?: string) => {
    setSending(true);
    try {
      const param = schedule ? `?schedule=${schedule}&force=true` : "?force=true";
      const res = await fetch(`/api/status-requests/send${param}`);
      const data = await res.json();
      console.log("[StatusDashboard] Send result:", data);
      await fetchRequests();
    } catch (err) {
      console.error("Failed to send status requests:", err);
    } finally {
      setSending(false);
    }
  };

  // Delete status request
  const deleteRequest = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this status update?")) return;
    try {
      const res = await fetch(`/api/status-requests?id=${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        setRequests((prev) => prev.filter((r) => r.id !== id));
        if (onShowToast) {
          onShowToast("status deleted successfully", "success");
        } else {
          alert("status deleted successfully");
        }
      } else {
        if (onShowToast) {
          onShowToast("Failed to delete status update.", "error");
        } else {
          alert("Failed to delete status update.");
        }
      }
    } catch (err) {
      console.error("Failed to delete status update:", err);
      if (onShowToast) {
        onShowToast("Failed to delete status update.", "error");
      } else {
        alert("Failed to delete status update.");
      }
    }
  };

  // Summary stats
  const stats = useMemo(() => {
    const total = requests.length;
    const replied = requests.filter((r) => r.status === "replied").length;
    const waiting = requests.filter((r) => r.status === "sent").length;
    const notReplied = requests.filter((r) => r.status === "not_replied").length;
    return { total, replied, waiting, notReplied };
  }, [requests]);

  // Group by schedule
  const grouped = useMemo(() => {
    const groups: Record<string, StatusRequest[]> = {
      morning: [],
      midday: [],
      evening: [],
    };
    requests.forEach((r) => {
      if (groups[r.schedule_label]) {
        groups[r.schedule_label].push(r);
      }
    });
    return groups;
  }, [requests]);

  if (loading) {
    return (
      <div className="status-dashboard-loading">
        <RefreshCw size={20} className="spin-animation" />
        <span>Loading status dashboard…</span>
      </div>
    );
  }

  return (
    <div className="status-dashboard">
      {/* Header */}
      <div className="status-header">
        <div className="status-header-left">
          <h2 className="status-title" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <BarChart2 size={20} style={{ color: 'var(--green)' }} />
            <span>Employee Status Dashboard</span>
          </h2>
          <p className="status-subtitle">
            Automated project update tracking via WhatsApp 
            <span style={{ marginLeft: "8px", color: "#10b981", fontSize: "0.75rem", background: "rgba(16, 185, 129, 0.1)", padding: "2px 6px", borderRadius: "4px" }}>
              ● Auto-Scheduler Active
            </span>
          </p>
        </div>
        <div className="status-header-right" style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div className="status-date-selector" style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'var(--panel)', padding: '6px 12px', borderRadius: '8px', border: '1px solid var(--line)', height: '38px' }}>
            <Calendar size={15} style={{ color: 'var(--muted)' }} />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              style={{
                background: 'transparent',
                border: 'none',
                color: 'var(--ink)',
                fontSize: '0.85rem',
                fontWeight: 600,
                outline: 'none',
                cursor: 'pointer',
                fontFamily: 'inherit'
              }}
            />
          </div>
          <button
            className="primary-button status-send-btn"
            onClick={() => sendNow()}
            disabled={sending}
            style={{ height: '38px' }}
          >
            <Send size={14} />
            {sending ? "Sending…" : "Send Status Request Now"}
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="status-summary-grid">
        <div className="status-summary-card">
          <span className="status-summary-number">{stats.total}</span>
          <span className="status-summary-label">Total Requests</span>
        </div>
        <div className="status-summary-card replied">
          <span className="status-summary-number">{stats.replied}</span>
          <span className="status-summary-label" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
            <CheckCircle2 size={12} style={{ color: 'var(--green)' }} /> Replied
          </span>
        </div>
        <div className="status-summary-card waiting">
          <span className="status-summary-number">{stats.waiting}</span>
          <span className="status-summary-label" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
            <Clock size={12} style={{ color: 'var(--amber)' }} /> Waiting
          </span>
        </div>
        <div className="status-summary-card not-replied">
          <span className="status-summary-number">{stats.notReplied}</span>
          <span className="status-summary-label" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
            <XCircle size={12} style={{ color: 'var(--red)' }} /> Not Replied
          </span>
        </div>
      </div>

      {/* Tables grouped by schedule */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginTop: '20px' }}>
        {(["morning", "midday", "evening"] as const).map((schedule) => {
          const items = grouped[schedule];
          const info = SCHEDULE_LABELS[schedule];

          return (
            <div className="status-schedule-block" key={schedule}>
              <h3 className="status-schedule-heading" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <info.icon size={18} style={{ color: 'var(--green)' }} />
                <span>{info.label} — {schedule.charAt(0).toUpperCase() + schedule.slice(1)} Check-in</span>
              </h3>

              {!items || items.length === 0 ? (
                <div style={{ padding: '24px', textAlign: 'center', color: 'var(--muted)', fontSize: '0.85rem', background: 'var(--panel)' }}>
                  No check-in requests sent for this schedule.
                </div>
              ) : (
                <>
                  {/* Desktop Table view */}
                  <div className="status-table-wrapper status-desktop-only">
                    <table className="status-table">
                      <thead>
                        <tr>
                          <th>Employee</th>
                          <th>Department</th>
                          <th>Project</th>
                          <th>Sent At</th>
                          <th>Reply Time</th>
                          <th>Response</th>
                          <th>Status</th>
                          <th>Latest Project Update</th>
                          <th style={{ width: "60px", textAlign: "center" }}>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((req) => (
                          <tr key={req.id} className={`status-row status-row-${req.status}`}>
                            <td>
                              <div className="status-cell-name">
                                <div className="status-avatar">
                                  {req.employee_name.charAt(0).toUpperCase()}
                                </div>
                                <span>{req.employee_name}</span>
                              </div>
                            </td>
                            <td>{req.department || "--"}</td>
                            <td>{req.project || "--"}</td>
                            <td style={{ whiteSpace: 'nowrap' }}>{formatTime(req.sent_at)}</td>
                            <td style={{ whiteSpace: 'nowrap' }}>{formatTime(req.reply_time)}</td>
                            <td style={{ whiteSpace: 'nowrap' }}>{getResponseTime(req.sent_at, req.reply_time)}</td>
                            <td>
                              {(() => {
                                const expired = isRequestExpired(req.reply_deadline, req.status);
                                const displayStatus = expired ? "not_replied" : req.status;
                                return (
                                  <span className={`status-badge-pill ${displayStatus}`}>
                                    {displayStatus === "replied" && (
                                      <><CheckCircle2 size={12} /> Replied</>
                                    )}
                                    {displayStatus === "sent" && (
                                      <><Clock size={12} /> Waiting</>
                                    )}
                                    {displayStatus === "not_replied" && (
                                      <><XCircle size={12} /> Not Replied</>
                                    )}
                                    {displayStatus === "pending" && (
                                      <><AlertCircle size={12} /> Pending</>
                                    )}
                                  </span>
                                );
                              })()}
                            </td>
                            <td className="status-cell-update">
                              <span>{req.update_text || "--"}</span>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <button
                                onClick={() => deleteRequest(req.id)}
                                className="status-delete-btn"
                                title="Delete status update"
                              >
                                <Trash2 size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile Card view */}
                  <div className="status-mobile-only" style={{ display: 'flex', flexDirection: 'column', gap: '12px', padding: '16px' }}>
                    {items.map((req) => {
                      const expired = isRequestExpired(req.reply_deadline, req.status);
                      const displayStatus = expired ? "not_replied" : req.status;
                      return (
                        <div 
                          key={req.id} 
                          className={`status-mobile-card status-row-${displayStatus}`}
                          style={{
                            background: 'var(--panel)',
                            border: '1px solid var(--line)',
                            borderRadius: '12px',
                            padding: '16px',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '12px',
                            position: 'relative',
                            boxShadow: 'var(--shadow)'
                          }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                              <div className="status-avatar" style={{ margin: 0 }}>
                                {req.employee_name.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <div style={{ fontWeight: 700, color: 'var(--ink)', fontSize: '0.9rem' }}>{req.employee_name}</div>
                                <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{req.department || "--"}</div>
                              </div>
                            </div>
                            <button
                              onClick={() => deleteRequest(req.id)}
                              className="status-delete-btn"
                              style={{ padding: '6px' }}
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>

                          <div style={{ 
                            display: 'grid', 
                            gridTemplateColumns: '1fr 1fr', 
                            gap: '8px 16px', 
                            fontSize: '0.78rem',
                            borderTop: '1px solid var(--line)',
                            borderBottom: '1px solid var(--line)',
                            padding: '10px 0'
                          }}>
                            <div>
                              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', marginBottom: '2px' }}>Project</span>
                              <span style={{ fontWeight: 600, color: 'var(--ink)' }}>{req.project || "--"}</span>
                            </div>
                            <div>
                              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', marginBottom: '2px' }}>Status</span>
                              <span className={`status-badge-pill ${displayStatus}`} style={{ padding: '2px 8px', fontSize: '0.68rem' }}>
                                {displayStatus === "replied" && "Replied"}
                                {displayStatus === "sent" && "Waiting"}
                                {displayStatus === "not_replied" && "Not Replied"}
                                {displayStatus === "pending" && "Pending"}
                              </span>
                            </div>
                            <div>
                              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', marginBottom: '2px' }}>Sent At</span>
                              <span style={{ fontWeight: 500 }}>{formatTime(req.sent_at)}</span>
                            </div>
                            <div>
                              <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', marginBottom: '2px' }}>Response Time</span>
                              <span style={{ fontWeight: 500 }}>{getResponseTime(req.sent_at, req.reply_time)}</span>
                            </div>
                          </div>

                          <div>
                            <span style={{ color: 'var(--muted)', display: 'block', fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', marginBottom: '4px' }}>Latest Project Update</span>
                            <div style={{ 
                              background: 'var(--panel-soft)', 
                              padding: '10px 12px', 
                              borderRadius: '8px', 
                              fontSize: '0.82rem', 
                              lineHeight: '1.4',
                              color: 'var(--ink)'
                            }}>
                              {req.update_text || "--"}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
